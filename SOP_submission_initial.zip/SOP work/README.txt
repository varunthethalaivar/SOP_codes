XGBoost:

    model_output1 and model_output2 are arduino executable C-code header files created by XGBoost_model notebook

    model_output3 and model_output4 are arduino executable C-code header files created by XGBoost_SPS30 notebook for the Sirion sensors

Random Forest:
    RF_output1 is an arduino executable C-code header files created by RF_SPS30 notebook for the Sirion sensors

Support Vector Regression:
    SVM_distilled is an arduino executable C-code header files created by SVM_model notebook

    SVM_output2 is an arduino executable C-code header files created by SVM_SPS30 notebook for the Sirion sensors

simulate.cpp is a C++ simulation of a sensor. It was used to test XGBoost Algorithm that was written.
simulate.exe contains the output of the simultion.
the outputs upon running the exe file are:
    Output 1: 78.3884
    Output 2: 87.824

